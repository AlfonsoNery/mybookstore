﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(nerytakehomequizisprog.Startup))]
namespace nerytakehomequizisprog
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
